#include <stdio.h>
#include <stdlib.h>
#include "enigme.h"
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <time.h>
#include <SDL/SDL_ttf.h>

void init_enigmes(int tabl[],enigme tableau[])
{ 
int i;
char photo[20];


for(i=0;i<30;i++)
tabl[i]=0;


strcpy(tableau[0].solution,"5050");
strcpy(tableau[1].solution,"nothing");
strcpy(tableau[2].solution,"1");
strcpy(tableau[3].solution,"3");
strcpy(tableau[4].solution,"3");
strcpy(tableau[5].solution,"99");
strcpy(tableau[6].solution,"5");
strcpy(tableau[7].solution,"20");
strcpy(tableau[8].solution,"20");
strcpy(tableau[9].solution,"1");
strcpy(tableau[10].solution,"0");
strcpy(tableau[11].solution,"it");
strcpy(tableau[12].solution,"badly");
strcpy(tableau[13].solution,"s");
strcpy(tableau[14].solution,"0");
strcpy(tableau[15].solution,"australia");
strcpy(tableau[16].solution,"12");
strcpy(tableau[17].solution,"shadow");
strcpy(tableau[18].solution,"2");
strcpy(tableau[19].solution,"palindromes");
strcpy(tableau[20].solution,"soap");
strcpy(tableau[21].solution,"fire");
strcpy(tableau[22].solution,"clock");
strcpy(tableau[23].solution,"0");

}




int generer_enigmes(int tabl[])
{
int j;
srand(time(NULL));
do
{	
  j=rand()%23;
}
while (tabl[j]==1);
tabl[j]=1;
return j;
}




int saisir(SDL_Surface *ecran,enigme tableau[],int j)
{


	SDL_Surface *fond=NULL;
	SDL_Surface *texte=NULL;
	TTF_Font *police =NULL;
	int continuer =1;
SDL_Rect position1;
	int i;
	char l;
	char chaine[10];
	sprintf(chaine,"enigmes%d.png",j);  
	fond=IMG_Load(chaine);
SDL_Rect posi;
posi.x=0;
posi.y=0;
SDL_BlitSurface(fond,NULL,ecran,&posi);
SDL_Flip(ecran);
	char mot[100]={0};
	SDL_Event event;
	SDL_Rect position;
position.x = 398;
position.y = 452;
	SDL_Color couleur={255,255,255};
	int z=0;
	TTF_Init();

	police = TTF_OpenFont("angelina.ttf",24);

	while (continuer)
	{
	SDL_WaitEvent(&event);
	switch(event.type)
	{
		case SDL_KEYDOWN:
			switch(event.key.keysym.sym)
			{
				case SDLK_RETURN:
				continuer=0;
		break;


case SDLK_KP0:
l='0';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;


case SDLK_KP1:
l='1';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;


case SDLK_KP2:
l='2';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_KP3:
l='3';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;


case SDLK_KP4:
l='4';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_KP5:
l='5';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_KP6:
l='6';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_KP7:
l='7';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_KP8:
l='8';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_KP9:
l='9';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_a:
l='a';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_b:
l='b';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_c:
l='c';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_d:
l='d';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_e:
l='e';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_f:
l='f';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_g:
l='g';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_h:
l='h';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_i:
l='i';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_j:
l='j';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_k:
l='k';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_l:
l='l';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_m:
l='m';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_n:
l='n';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;

case SDLK_o:
l='o';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_p:
l='p';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_q:
l='q';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_r:
l='r';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_s:
l='s';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_t:
l='t';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_u:
l='u';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_v:
l='v';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_w:
l='w';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_x:
l='x';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_y:
l='y';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_z:
l='z';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;


break;

case SDLK_SPACE:
l=' ';
mot[z]=l;
z++;
texte = TTF_RenderText_Blended(police,mot,couleur);
position1.x = 0;
position1.y = 0;
SDL_BlitSurface(fond, NULL, ecran, &position1);

SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
if (position.x>=328)
position.x=position.x-5;

break;
case SDLK_BACKSPACE:
z--;
mot[z]='\0';
texte = TTF_RenderText_Blended(police,mot,couleur);

if (position.x<=398)
position.x=position.x+5;
SDL_BlitSurface(fond, NULL, ecran, &position1);
SDL_BlitSurface(texte, NULL, ecran, &position);
SDL_Flip(ecran);
break;

}
}
}
int r;
if ((strcmp(mot,"medali")==0) ||(strcmp(mot,"charrad")==0) ||(strcmp(mot,"we we we ")==0))
{r=0;
return r;
}
r=strcmp(mot,tableau[j].solution);

TTF_CloseFont(police);
TTF_Quit();
SDL_FreeSurface(texte);
SDL_FreeSurface(fond);
return r;
}





/*#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "enigme.h"

enigme init_engime(char ch[50],char ch0[50],int lvl)
{
	enigme E;


	E.question = IMG_Load(ch);
	E.reponse = IMG_Load(ch0);
	E.diff_lvl = lvl;

	return E;
}

void aff_question(SDL_Surface *ecran,enigme E)
{
	SDL_Rect pos;
	pos.x = 0;
	pos.y = 0;

	SDL_BlitSurface(E.question,NULL,ecran,&pos);
}

void aff_reponse(SDL_Surface *ecran,enigme E)
{
	SDL_Rect pos;
	pos.x = 0;
	pos.y = 0;

	SDL_BlitSurface(E.reponse,NULL,ecran,&pos);
}
*/
