#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>

#include "enigme.h"

int main()
{

char mot[20];
SDL_Surface *ecran = NULL;

SDL_Init(SDL_INIT_EVERYTHING);
ecran=SDL_SetVideoMode(800 ,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	enigme tableau[23];
	int tabl[23];
init_enigmes(tabl,tableau);
int j=generer_enigmes(tabl);

int x=saisir(ecran,tableau, j);
if(x==0)
{
printf("C'est juste\n");
system("sendemail -f simhamda3li@gmail.com -t mohamedali.charrad@esprit.tn -u reponse -m \"C'est Juste \n Bravo\" -s smtp.gmail.com:587 -o tls=yes -xu firstgame66@gmail.com -xp charrad1998");
}
else
{
printf("C'est faux\n");

//system("sendemail -f gamefirst@gmail.com -t 0021654010700@txtlocal.co.uk -u Why -m \" C'est faux \" -s smtp.gmail.com:587 -o tls=yes -xu firstgame66@gmail.com -xp charrad1998");
}

SDL_FreeSurface(ecran);
SDL_Quit();
	return 0;
}


