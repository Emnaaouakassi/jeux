
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "perpix.h"
SDL_Color GetPixel(SDL_Surface *pSurface,int x,int y)
{
SDL_Color color;
Uint32 col=0;
//Determine position
char* pPosition=(char*)pSurface->pixels;
pPosition+=(pSurface->pitch*y);
pPosition+=(pSurface->format->BytesPerPixel*x);
memcpy(&col,pPosition,pSurface->format->BytesPerPixel);
//convertir color
SDL_GetRGB(col,pSurface->format,&color.r,&color.g,&color.b);
return(color);
}
int collision(SDL_Surface *calque,hero peter,int decalage,int d)
{
SDL_Color col;
int colli=0;
if(d==6)//imin
  {
    col=GetPixel(calque,peter.position_map.x+peter.frame.w+decalage,peter.position_map.y+(peter.frame.h/2));
  }
else  if(d==4)//issarr
  {
    col=GetPixel(calque,peter.position_map.x +decalage,peter.position_map.y+(peter.frame.h/2));
  }
else  if(d==8)//lfou9
  {
    col=GetPixel(calque,peter.position_map.x+(peter.frame.w/2)+decalage ,peter.position_map.y);
  }
else  if(d==2)//louta
  {
    col=GetPixel(calque,peter.position_map.x+(peter.frame.w/2) +decalage,peter.position_map.y+peter.frame.h);
  }
if ((col.r==0)&&(col.b==0)&&(col.g==0))
colli=1;
return colli;

}

