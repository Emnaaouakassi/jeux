#ifdef COLLISION_H_
#define COLLISION_H_
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
typedef struct pos
{
int x,y;
}pos;
typedef struct f
{
int h,w;
}f;
typedef struct hero
{
pos position_map;
f frame;
}hero;

SDL_Color GetPixel(SDL_Surface *pSurface,int x,int y);
int collision(SDL_Surface *calque,hero peter,int decalage,int d);
#endif
