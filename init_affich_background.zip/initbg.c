#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "bg.h"
#include <stdio.h>
#include <stdlib.h>
void initbg(maps *map)
{
map->calque=IMG_Load("calque.png");
map->affichage_map=IMG_Load("map.png");
map->pose.x=0;
map->pose.y=0;
map->pos.x=0;
map->pos.y=0;
map->pos.h=1020;
map->pos.w=2000;
}
void affibg(maps map,SDL_Surface *ecran)
{
int i=1;
SDL_Event event;
while(i==1)
	{
SDL_PollEvent(&event);
switch(event.type)
{
case SDL_QUIT:
 i=0;
break;
}
SDL_BlitSurface(map.affichage_map,&(map.pos),ecran,&(map.pose));
SDL_Flip(ecran);
}

}
