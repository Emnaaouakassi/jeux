#ifndef FONCTIONS_H_
#define FONCTIONS_H_

typedef struct
{
SDL_Surface *calque,*affichage_map;
SDL_Rect pose,pos;
}maps;
void initbg(maps *map);
void affibg(maps map,SDL_Surface *ecran);



#endif /* FONCTIONS_H_ */
