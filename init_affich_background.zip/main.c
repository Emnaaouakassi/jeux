#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "bg.h"
#include <stdio.h>
#include <stdlib.h>
void main()
{
SDL_Surface *ecran=NULL;
maps map;
SDL_Init(SDL_INIT_EVERYTHING);
ecran=SDL_SetVideoMode(1920,1020,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
initbg(&map);
affibg(map,ecran);
}
