var searchData=
[
  ['initsprite',['InitSprite',['../jump_8c.html#ac03b8314b6b63e055d6928073a58b722',1,'jump.c']]]
];
