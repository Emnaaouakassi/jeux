#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "bg.h"
#include <stdio.h>
#include <stdlib.h>
maps initbg(maps map)
{
map.h=1020;
map.w=5000;
map.calque=IMG_Load("calque.png");
map.affichage_map=IMG_Load("map.png");
return map;
}

