#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "bg.h"
#include <stdio.h>
#include <stdlib.h>
void initbg(maps *map,SDL_Surface *ecran)
{
map->h=1020;
map->w=5000;
map->calque=IMG_Load("calque.png");
map->affichage_map=IMG_Load("map.png");
int i=1;
SDL_Event event;
while(i==1)
	{
SDL_PollEvent(&event);
switch(event.type)
{
case SDL_QUIT:
 i=0;
break;
}
SDL_BlitSurface(map->affichage_map,NULL,ecran,NULL);
SDL_Flip(ecran);
}

}
