#ifndef FONCTIONS_H_
#define FONCTIONS_H_

typedef struct
{
int h,w;
SDL_Surface *calque,*affichage_map;
SDL_Rect pose;
}maps;
maps initbg(maps map);


#endif /* FONCTIONS_H_ */
