#ifndef FONCTIONS_H_
#define FONCTIONS_H_

typedef struct
{
int h,w;
SDL_Surface *calque,*affichage_map;
SDL_Rect pose;
}maps;
void initbg(maps *map,SDL_Surface *ecran);



#endif /* FONCTIONS_H_ */
