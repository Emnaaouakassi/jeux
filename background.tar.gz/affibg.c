#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <string.h>
#include <SDL/SDL_ttf.h>
#include "bg.h"
#include <stdio.h>
#include <stdlib.h>
void affichebg(maps map,SDL_Surface ecran)
{
SDL_BlitSurface(map.affichage_map,NULL,&ecran,&map.pose);
}
