#ifndef ANIMATION_H_INCLUDED
#define ANIMATION_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <time.h> 
#include <unistd.h>
typedef struct score
{
SDL_Rect ps;
 SDL_Surface *fond1;
}score;
void init_score( score *s);
int afficherscore(score *s,SDL_Surface *screen  );
#endif
